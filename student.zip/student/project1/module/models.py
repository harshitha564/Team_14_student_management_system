from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class UserProfileInfo(models.Model):
     #user = models.OneToOneField(User,on_delete=models.CASCADE)
     username = models.CharField(max_length=30, default='')
     email_id = models.CharField(max_length=30, default='@gmail.com')
     password = models.CharField(max_length=30, default='')
     confirm_password = models.CharField(max_length=30, default='')
     
     
  
	
def __str__(self):
  return self.UserProfileInfo.username, self.UserProfileInfo.password

# Create your models here.

