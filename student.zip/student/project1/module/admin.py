from django.contrib import admin
from module.models import UserProfileInfo, User

admin.site.register(UserProfileInfo)

